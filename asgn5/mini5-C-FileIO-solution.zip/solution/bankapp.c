/*
 Program to implement a small banking application
 *********************************************
 ***************************************************************
 * Author         Dept.             Date          Notes
 ***************************************************************
 * Joseph D       Comp. Science. Feb 18 2020    Initial version.
*/


// For printf, fprintf, fopen, fclose, fseek
#include <stdio.h>

// For atof
#include <stdlib.h>

// For strcmp, strtok
#include <string.h>

// Function to add a new account.
// Accepts the data file, account number and customer name as arguments.
int addacct(FILE* bankdata, char* acctnum, char* acctname)
{
	char rec[100];
	while (fgets(rec, 99, bankdata)) //read one line at a time.
	{
		char* field = strtok(rec, ","); //used to parse the line into its fields.
		if(field == NULL) // empty line perhaps ?
			break;
		if(strcmp(field, "AC")==0) // first field is AC if it is an account record.
		{
			field = strtok(NULL, ",");	// second field is the account number.
			if(strcmp(field, acctnum) == 0)	// does the new account number already exists?
			{
				fprintf(stderr, "Error, account number %s already exists\n", acctnum);
				return 50;
			}
		}
	}
	// Add the new account information to the file.
	fprintf(bankdata, "AC,%s,%s\n", acctnum, acctname);
	return 0;
}

// Function to deposit money into an account.
// Accepts the data file, account number, date and amount as arguments.
int deposit(FILE* bankdata, char* acctnum, char* txdate, char* amount)
{
	char rec[100];
	int acctexists = 0;

	// First step is to ensure that the account exists.
	while (fgets(rec, 99, bankdata)) // read through each line
	{
		char* field = strtok(rec, ",");
		if(field == NULL)
			break;
		if(strcmp(field, "AC")==0) // account information records
		{
			field = strtok(NULL, ",");
			if(strcmp(field, acctnum) == 0)	//We found the account record.
			{
				acctexists = 1;
				fseek(bankdata, 0, SEEK_END); // Move to the end of the file.
				break;
			}
		}
	}

	if(!acctexists) // we did not find the account
	{
		fprintf(stderr, "Error, account number %s does not exists\n", acctnum);
		return 50;
	}

	// Add the deposit transaction to the end of the file.
	fprintf(bankdata, "TX,%s,%s,%s\n", acctnum, txdate, amount);
	return 0;
}

// Function to withdraw money from an account.
// Accepts the data file, account number, date and amount as arguments.
int withdraw(FILE* bankdata, char* acctnum, char* txdate, char* amount)
{
	char rec[100];
	int acctexists = 0;
	float withdrawamt, acctbalance = 0.0;
	withdrawamt = atof(amount);

	while (fgets(rec, 99, bankdata)) // read data file line by line
	{
		char* field = strtok(rec, ",");
		if(field == NULL)
			break;
		if(strcmp(field, "AC")==0) // Account records
		{
			field = strtok(NULL, ",");
			if(strcmp(field, acctnum) == 0)	// We found the record.
				acctexists = 1;
		}
		if(strcmp(field, "TX")==0)	// Deposit / withdrawal records
		{
			field = strtok(NULL, ","); // Account num
			if(strcmp(field, acctnum) == 0)
			{
				field = strtok(NULL, ","); // TX Date field
				field = strtok(NULL, ","); // Deposit / Withdrawal amount
				acctbalance += atof(field); // To find the total balance in the acct.
			}
		}
	}

	if(!acctexists)
	{
		fprintf(stderr, "Error, account number %s does not exists\n", acctnum);
		return 50;
	}

	if(acctbalance < withdrawamt)	//Not enough money in the account.
	{
		fprintf(stderr, "Error, account number %s has only %.2f\n", acctnum, acctbalance);
		return 60;
	}

	// Add a withdrawal transaction to the data file.
	fprintf(bankdata, "TX,%s,%s,-%s\n", acctnum, txdate, amount);
	return 0;
}

// Main of the program.
int main(int argc, char* argv[])
{
	const char* BANKDATA = "bankdata.csv";	//This is our data file in CSV format.
	FILE *bankdata;
	int rc = 0;

	if(argc < 3)	// Basic check for proper usage.
	{
		fprintf(stderr, "Error, incorrect usage!\n");
		fprintf(stderr, "-a ACCTNUM NAME\n");
		fprintf(stderr, "-d ACCTNUM DATE AMOUNT\n");
		fprintf(stderr, "-w ACCTNUM DATE AMOUNT\n");
		return 1;
	}
	
	bankdata = fopen(BANKDATA, "r+");	// Open the data file for reading and any appends.
	if(bankdata == NULL) // could not locate the data file.
	{
		fprintf(stderr, "Error, unable to locate the data file %s\n", BANKDATA);
		return 100;
	}

	if(strcmp(argv[1], "-a")==0)	// Add a new account
	{
		//printf("Adding new account\n");
		if(argc < 4)
		{
			fprintf(stderr, "Error, incorrect usage!\n");
			fprintf(stderr, "-a ACCTNUM NAME\n");
			rc=1;
		}
		else
			rc = addacct(bankdata, argv[2], argv[3]);
	}
	else if(strcmp(argv[1], "-d")==0)	// Deposit some money
	{
		//printf("Deposit transaction\n");
		if(argc < 5)
		{
			fprintf(stderr, "Error, incorrect usage!\n");
			fprintf(stderr, "-d ACCTNUM DATE AMOUNT\n");
			rc=1;
		}
		else
			rc = deposit(bankdata, argv[2], argv[3], argv[4]);
	}
	else if(strcmp(argv[1], "-w")==0) // Withdraw some money.
	{
		//printf("Withdrawal transaction\n");
		if(argc < 5)
		{
			fprintf(stderr, "Error, incorrect usage!\n");
			fprintf(stderr, "-w ACCTNUM DATE AMOUNT\n");
			rc=1;
		}
		else
			rc = withdraw(bankdata, argv[2], argv[3], argv[4]);
	}
	else // Not a recognized command.
	{
		fprintf(stderr, "Error invalid command %s\n", argv[1]);
		rc=2;
	}

	fclose(bankdata); //close the data file before we exit.
	return rc;
}
