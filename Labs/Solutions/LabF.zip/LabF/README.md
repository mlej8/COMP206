main.c contains all code snippets for Lab F.
Multiple methods were created for the different part of the questions.
Uncomment the method you want to test in the main function or change the main as you wish to do your own tests.