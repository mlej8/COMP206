Zoom lab video uploaded: https://mcgill-my.sharepoint.com/:v:/g/personal/ridwan_kurmally_mcgill_ca/Eaz0U78XNqxPliu6d8xr1WcBtcGH0nGPHzlPrV8vki8cPg?e=nRYDRr


There are 3 different approach to the question.


1.) Using Shared memory

2.) Using Shell memory (note that the implementation is correct but not running linux because of configurations settings. Code is however still valid for final)

3.) Using textfile


A "run.sh" bash script, to compile/run the code, is included for each solution.
Run script through the command: "./run.sh"