I have attached screenshots of my terminal as I was doing the lab on the Mimi server.

The screenshots fully covers Q2 and Q3.

As for Q1, there are a lot of resources on MyCourses and Piazza posts to help you create and login onto Mimi.

Thank you!
