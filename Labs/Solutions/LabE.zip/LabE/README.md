names.c is the solution to Question 1


names2.c is the solution to Question 2


matrix.c shows the code to implement matrix printing and multiplication.
