bank.c : Solution to Question 1 


bank2.c : Solution to Question 2 (Dynamic Memory Allocation)